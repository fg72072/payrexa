import logo from './logo.svg';
import './App.css';
import './asssets/Style.css';
import {Header,Footer} from './components';
import Index from './screens';
function App() {
  return (
    <div className="App">
     <Header/>
     <Index/>
     <Footer/>
    </div>
  );
}

export default App;
