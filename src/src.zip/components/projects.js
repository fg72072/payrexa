import React, { useEffect, useState } from 'react';
import axios from 'axios';
function Projects() {
	const [ projects, setProjects ] = useState([]);
	useEffect(async () => {
		await axios.get('http://localhost/lumen_api/public/projects').then((res) => {
			setProjects(res.data.projects);
		});
	},[]);
	return (
		<div>
			<section class="ftco-section ftco-project" id="projects-section">
				<div class="container-fluid px-md-4">
					<div class="row justify-content-center pb-5">
						<div class="col-md-12 heading-section text-center ">
							<span class="subheading">Accomplishments</span>
							<h2 class="mb-4">Our Projects</h2>
							<p>
								Far far away, behind the word mountains, far from the countries Vokalia and Consonantia
							</p>
						</div>
					</div>
					<div class="row">
						{projects.map((project) => {
							return (
								<div class="col-md-3">
									<div
										class="project img shadow  d-flex justify-content-center align-items-center"
										style={{
											backgroundImage: `url(${require('../asssets/images/'+project.image_name.split(',')[0]).default})`
										}}
									>
										<div class="overlay" />
										<div class="text text-center p-4">
											<h3>
												<a href="#">{project.title}</a>
											</h3>
											<span>{project.category_name.split(',')[0]}</span>
										</div>
									</div>
								</div>
							);
						})}
					</div>
				</div>
			</section>
		</div>
	);
}
export default Projects;
