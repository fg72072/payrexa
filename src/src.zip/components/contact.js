function Contact(props) {
	return (
		<div>
			<section class="ftco-section contact-section ftco-no-pb" id="contact-section">
				<div class="container">
					<div class="row justify-content-center mb-5 pb-3">
						<div class="col-md-7 heading-section text-center ">
							<span class="subheading">Contact us</span>
							<h2 class="mb-4">Have a Project?</h2>
							<p>
								Far far away, behind the word mountains, far from the countries Vokalia and Consonantia
							</p>
						</div>
					</div>
					<div class="row block-9">
						<div class="col-md-8">
							<form action="#" class="bg-light p-4 p-md-5 contact-form">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Your Name" />
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Your Email" />
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Subject" />
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<textarea
												name=""
												id=""
												cols="30"
												rows="7"
												class="form-control"
												placeholder="Message"
											/>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input
												type="submit"
												value="Send Message"
												class="btn btn-primary py-3 px-5"
											/>
										</div>
									</div>
								</div>
							</form>
						</div>
						<div class="col-md-4 d-flex pl-md-5">
							{props.contacts.map((contact) => {
								return <div class="row">
									<div class="dbox w-100 d-flex">
										<div class="icon d-flex align-items-center justify-content-center">
											<span class="fa fa-map-marker" />
										</div>
										<div class="text">
											<p>
												<span>Address:</span> {contact.address}
											</p>
										</div>
									</div>
									<div class="dbox w-100 d-flex">
										<div class="icon d-flex align-items-center justify-content-center">
											<span class="fa fa-phone" />
										</div>
										<div class="text">
											<p>
												<span>Phone:</span> <a href="tel://1234567920">{contact.phone}</a>
											</p>
										</div>
									</div>
									<div class="dbox w-100 d-flex">
										<div class="icon d-flex align-items-center justify-content-center">
											<span class="fa fa-paper-plane" />
										</div>
										<div class="text">
											<p>
												<span>Email:</span>{' '}
												<a href="https://preview.colorlib.com/cdn-cgi/l/email-protection#6c05020a032c1503191e1f051809420f0301">
													<span
														class="__cf_email__"
														data-cfemail="e28b8c848da29b8d9790918b9687cc818d8f"
													>
														{contact.email2}
													</span>
												</a>
											</p>
										</div>
									</div>
									<div class="dbox w-100 d-flex">
										<div class="icon d-flex align-items-center justify-content-center">
											<span class="fa fa-globe" />
										</div>
										<div class="text">
											<p>
												<span>Website</span> <a href="#">{contact.phone}</a>
											</p>
										</div>
									</div>
								</div>;
							})}
						</div>
					</div>
				</div>
			</section>
		</div>
	);
}
export default Contact;
