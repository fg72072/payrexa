import { Carousel, Row, Col } from 'react-bootstrap';
import React, { useState } from 'react';
function ControlledCarousel() {
	return (
		<Carousel>
			<Carousel.Item>
				<Row>
					<Col lg="4">
						<div class="text banner-text text-center">
							<span class="subheading">Hello! This is Clyde</span>
							<h1 class="mb-4 mt-3">
								Creative <span>UI/UX</span> Designer &amp; Developer
							</h1>
							<p>
								<a href="#" class="btn btn-primary">
									Hire me
								</a>{' '}
								<a href="#" class="btn btn-primary btn-outline-primary">
									Download CV
								</a>
							</p>
						</div>
					</Col>
					<Col lg="8">
						<img
							className="d-block banner-image"
							src={require('../asssets/images/banner1.jpg').default}
							alt="First slide"
						/>
					</Col>
				</Row>
				<Carousel.Caption />
			</Carousel.Item>
			<Carousel.Item>
				<Row>
					<Col lg="4">
					<div class="text banner-text text-center">
							<span class="subheading">Hello! This is Clyde</span>
							<h1 class="mb-4 mt-3">
								Creative <span>UI/UX</span> Designer &amp; Developer
							</h1>
							<p>
								<a href="#" class="btn btn-primary">
									Hire me
								</a>{' '}
								<a href="#" class="btn btn-primary btn-outline-primary">
									Download CV
								</a>
							</p>
						</div>
					</Col>
					<Col lg="8">
						<img
							className="d-block banner-image"
							src={require('../asssets/images/banner1.jpg').default}
							alt="First slide"
						/>
					</Col>
				</Row>
				<Carousel.Caption />
			</Carousel.Item>
			<Carousel.Item>
				<Row>
					<Col lg="4">
                    <div class="text banner-text text-center">
							<span class="subheading">Hello! This is Clyde</span>
							<h1 class="mb-4 mt-3">
								Creative <span>UI/UX</span> Designer &amp; Developer
							</h1>
							<p>
								<a href="#" class="btn btn-primary">
									Hire me
								</a>{' '}
								<a href="#" class="btn btn-primary btn-outline-primary">
									Download CV
								</a>
							</p>
						</div>
					</Col>
					<Col lg="8">
						<img
							className="d-block banner-image"
							src={require('../asssets/images/banner1.jpg').default}
							alt="First slide"
						/>
					</Col>
				</Row>

				<Carousel.Caption />
			</Carousel.Item>
		</Carousel>
	);
}
export default ControlledCarousel;
