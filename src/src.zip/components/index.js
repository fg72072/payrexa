import Header from './header';
import Footer from './footer';
import ControlledCarousel from './carousel';
import About from './about';
import Skills from './skills';
import Services from './services';
import Projects from './projects';
import Contact from './contact';


export {Header,Footer,ControlledCarousel,About,Skills,Services,Projects,Contact};