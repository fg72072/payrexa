import { Container } from "react-bootstrap";

function Header(){
    return (
        <>
        <div className="sticky-nav">
        <Container>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <svg width="50" height="50" fill="none" xmlns="http://www.w3.org/2000/svg" class="">
            <path
              d="M20 3.464a4 4 0 014 0L39.65 12.5a4 4 0 012 3.464v18.072a4 4 0 01-2 3.464L24 46.536a4 4 0 01-4 0L4.35 37.5a4 4 0 01-2-3.464V15.964a4 4 0 012-3.464L20 3.464z"
              stroke="url(#paint0_linear)" stroke-width="4"></path>
            <defs>
              <linearGradient id="paint0_linear" x1="6.5" y1="46" x2="46.5" y2="5" gradientUnits="userSpaceOnUse">
                <stop stop-color="#0EACD2"></stop>
                <stop offset="1" stop-color="#9833FD"></stop>
              </linearGradient>
            </defs>
          </svg>
          Obiex
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse d-flex custom-nav" id="navbarSupportedContent">

          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="custom-link nav-link active" aria-current="page" href="#">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="custom-link nav-link" href="#">Invest & Earn</a>
            </li>
            <li class="nav-item">
              <a class="custom-link nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item">
              <a class="custom-link nav-link" href="#">Blog</a>
            </li>
            <li class="nav-item">
              <a class="custom-link nav-link" href="#">Login</a>
            </li>
            <li class="nav-item">
              <a class="custom-link nav-link" href="#">Register</a>
            </li>
          </ul>

          <div class="d-flex">
            <div class="social-links-section"><a target="_blank" href="https://facebook.com/obiexfinance"><img
                  loading="lazy" src="https://obiex.finance/assets/images/facebook_dark.svg" width="20"
                  height="20"/></a><a target="_blank" href="https://t.me/joinchat/U5jIDQ3cSYYdabGr"><img loading="lazy"
                  src="https://obiex.finance/assets/images/telegram_dark.svg" width="20" height="20"/></a><a
                target="_blank" href="https://twitter.com/obiexfinance"><img loading="lazy"
                  src="https://obiex.finance/assets/images/twitter_dark.svg" width="20" height="20"/></a><a
                target="_blank" href="https://instagram.com/obiexfinance"><img loading="lazy"
                  src="https://obiex.finance/assets/images/instagram_dark.svg" width="20" height="20"/></a></div>
          </div>
        </div>
      </div>
    </nav>
  </Container>
        </div>
        </>
    )
}
export default Header;