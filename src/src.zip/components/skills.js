import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Skills() {
    const [skills,setSkills] = useState([]);
    useEffect(async ()=>{
       await axios.get('http://localhost/lumen_api/public/skills').then((res)=>{
           setSkills(res.data.skills)
       })
    },[]);
	return (
		<div>
			<section class="ftco-section bg-light" id="skills-section">
				<div class="container">
					<div class="row justify-content-center pb-5">
						<div class="col-md-12 heading-section text-center ">
							<span class="subheading">Skills</span>
							<h2 class="mb-4">My Skills</h2>
							<p>
								Far far away, behind the word mountains, far from the countries Vokalia and Consonantia
							</p>
						</div>
					</div>
					<div class="row progress-circle mb-5">
                        {
                            skills.map((skill)=>{
                            return <div class="col-lg-4 mb-4">
							<div class="bg-white rounded-lg shadow p-4">
								<h2 class="h5 font-weight-bold text-center mb-4">{skill.title}</h2>

								<div class="progress mx-auto" data-value="95">
									<span class="progress-left">
										<span class="progress-bar border-primary" />
									</span>
									<span class="progress-right">
										<span class="progress-bar border-primary" />
									</span>
									<div class="progress-value w-100 h-100 rounded-circle d-flex align-items-center justify-content-center">
										<div class="h2 font-weight-bold">
											{/* 95<sup class="small">%</sup> */}
                                            <img src={require('../asssets/images/about-1.jpg').default}/>
										</div>
									</div>
								</div>
							</div>
						</div>
                            })
                        }
					</div>
				</div>
			</section>
		</div>
	);
}
export default Skills;
