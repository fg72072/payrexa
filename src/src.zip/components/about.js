import { React, useState, useEffect } from 'react';
import axios from 'axios';
function About(props) {
	let [ hobbies, setHobbies ] = useState([]);
	useEffect(async () => {
		await axios
			.get('http://localhost/lumen_api/public/hobbies')
			.then((res) => {
				setHobbies(res.data.hobbies);
			})
			.catch((error) => {});
	}, []);
	return (
		<div>
			<section class="ftco-about ftco-section ftco-no-pt ftco-no-pb" id="about-section">
				<div class="container">
					<div class="row d-flex no-gutters">
						<div class="col-md-6 col-lg-5 d-flex">
							{props.users.map((user) => {
								return (
									<div
										class="about-img img d-flex align-items-stretch"
										style={{
											backgroundImage: `url(${require('../asssets/images/' + user.profile)
												.default})`
										}}
									>
										<div class="overlay" />
										<div class="test-image img d-flex align-self-stretch align-items-center" />
									</div>
								);
							})}
						</div>
						<div class="col-md-6 col-lg-7 pl-md-4 pl-lg-5 py-5">
							<div class="py-md-5">
								<div class="row justify-content-start pb-3">
									{props.users.map((user) => {
										return (
											<div class="col-md-12 heading-section ">
												<span class="subheading">My Intro</span>
												<h2 class="mb-4">About Me</h2>
												<p>{user.intro}</p>
												<ul class="about-info mt-4 px-md-0 px-2">
													<li class="d-flex">
														<span>Name:</span> <span>{user.name}</span>
													</li>
													<li class="d-flex">
														<span>Date of birth:</span> <span>{user.dob}</span>
													</li>
													<li class="d-flex">
														<span>Address:</span> <span>{user.address}</span>
													</li>
													<li class="d-flex">
														<span>Email:</span>{' '}
														<span>
															<a>{user.email2}</a>
														</span>
													</li>
													<li class="d-flex">
														<span>Phone: </span> <span>{user.phone}</span>
													</li>
												</ul>
											</div>
										);
									})}
									<div class="col-md-12">
										<div class="my-interest d-lg-flex w-100">
											{hobbies.map((hobby) => {
												return <div class="interest-wrap d-flex align-items-center">
													<div class="icon d-flex align-items-center justify-content-center">
														<span class="flaticon-listening" />
													</div>
													<div class="text">{hobby.title}</div>
												</div>
											})}
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
}
export default About;
