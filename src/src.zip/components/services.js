import React, { useEffect, useState } from 'react';
import axios from 'axios';
function Services(){
    const [services,setServices] = useState([]);
    useEffect(async ()=>{
        await axios.get("http://localhost/lumen_api/public/services").then((res)=>{
            setServices(res.data.services)
        })
    },[])
    return (
        <div>
            <section class="ftco-section" id="services-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 heading-section text-center  mb-5">
                    <span class="subheading">I am grat at</span>
                    <h2 class="mb-4">We do awesome services for our clients</h2>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p>
                </div>
            </div>
            <div class="row">
                {
                    services.map((service)=>{
                      return  <div class="col-md-6 col-lg-3">
                        <div class="media block-6 services d-block bg-white rounded-lg shadow ">
                            <div class="icon shadow d-flex align-items-center justify-content-center"><span
                                    class="flaticon-branding"></span></div>
                            <div class="media-body">
                                <h3 class="heading mb-3">{service.title}</h3>
                                <p>{service.description}</p>
                            </div>
                        </div>
                    </div>
                    })
                }
               
            </div>

        </div>
    </section>
    <section class="ftco-hireme">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-md-8 col-lg-8 d-flex align-items-center">
                    <div class="w-100 py-4">
                        <h2>Have a project on your mind.</h2>
                        <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.
                            It is a paradisematic country, in which roasted parts of sentences fly.</p>
                        <p class="mb-0"><a href="#" class="btn btn-white py-3 px-4">Contact me</a></p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 d-flex align-items-end">
                    <img src={require('../asssets/images/banner1.jpg').default} class="img-fluid" alt=""/>
                </div>
            </div>
        </div>
    </section>
        </div>
    )
}
export default Services;