import { React, useState, useEffect } from 'react';
import axios from 'axios';

import {  ControlledCarousel,About, Skills, Services, Projects, Contact } from '../components';
function Index() {
    let [ users, setUsers ] = useState([]);
	useEffect(async () => {
		await axios
			.get('http://localhost/lumen_api/public/user')
			.then((res) => {
				setUsers(res.data.users);
			})
			.catch((error) => {});
	}, []);
	return (
		<div>
			<ControlledCarousel />
			<About users={users}/>
			<Skills />
			<Services />
			<Projects />
			<Contact contacts={users}/>
		</div>
	);
}
export default Index